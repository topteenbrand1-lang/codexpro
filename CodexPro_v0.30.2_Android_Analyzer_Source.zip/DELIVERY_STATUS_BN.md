# CodexPro v0.30.2 — Build & Platform Audit (বাংলা)

## বর্তমান অবস্থা

এই প্যাকেজটি মূলত Node.js 20+ এবং TypeScript-ভিত্তিক CodexPro MCP server। এটি নিজে থেকে Android APK বা পূর্ণাঙ্গ standalone web client নয়। HTTP server-এ configuration/admin UI আছে (`src/http.ts`), এবং `docs/`-এ static project website আছে।

## এই পরিবেশে যাচাই

| Check | ফলাফল | নোট |
|---|---|---|
| ZIP extraction | PASS | সোর্স আর্কাইভ খোলা গেছে |
| Node.js runtime | PASS | Node v22.16.0 |
| `node scripts/release-guard.mjs` | PASS | release guard passed |
| `node --check scripts/codexpro.mjs` | PASS | syntax check |
| `node --check scripts/http-smoke.mjs` | PASS | syntax check |
| `node scripts/doctor-smoke.mjs` | PASS | doctor smoke test passed |
| `npm ci --no-audit --no-fund` | BLOCKED | registry/network install timed out |
| `npm ci --offline` | BLOCKED | npm cache lacks `zod-to-json-schema@3.25.2` |
| `npm run build` | BLOCKED | incomplete type-definition packages; TS2688 for node/express and related types |
| Full smoke/stress/audit suite | NOT RUN | requires a complete install/build first |
| Android APK | NOT BUILT | no Android project/manifest/Gradle setup in source archive |
| Separate web client | NOT BUILT | no Vite/React/browser-client scaffold; existing server UI and docs site are present |

## Security notes from project documentation

- Public tunnel mode and non-loopback binds must have a strong HTTP token (minimum 24 bytes per project policy).
- Never share a connector URL containing `codexpro_token` or tunnel credentials.
- Prefer safe bash; avoid full shell access unless the repository and user session are trusted.
- Workspace write mode has real file-change impact; use a reviewable workflow and inspect diffs.
- Workspace path guards are defense-in-depth, not an operating-system sandbox.
- Do not expose local handoff execution or autonomous loops as remote tools without a stronger approval/sandbox design.

## Next steps to complete a verified release

1. Run `npm ci --no-audit --no-fund` in a network-enabled environment with Node.js 20+.
2. Confirm `npm ls --depth=0` has no missing packages.
3. Run `npm run build`.
4. Run `npm run smoke` and `npm run stress`.
5. Run `npm audit --audit-level=high` and review findings rather than auto-fixing blindly.
6. Run `npm run release:pack` and `npm run package:smoke`.
7. Implement a separate responsive web client only after deciding which server capabilities should be exposed over a browser API. Do not give a browser arbitrary filesystem or shell access.
8. Decide Android architecture: (a) a WebView/PWA client connected to a separately running local CodexPro service, or (b) a bundled Android service. Option (b) needs a supported Android/Termux execution strategy, lifecycle handling, local-only binding by default, permissions review, and real-device testing. A thin WebView alone does not bundle the Node server.
9. Build with Android SDK/Gradle in a configured Android build environment and verify APK signature, install, launch, local connectivity, process lifecycle, and uninstall/reinstall behavior on a real device.

## Honest completion status

This is an initial source/build audit and platform plan, not a release certification. No claim is made that APK/Web client is built or that the complete test suite passed.
