package com.codexpro.analyzer

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var searchInput: EditText
    private var selectedTree: Uri? = null
    private val openTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            selectedTree = uri
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            analyzeTree(uri)
        }
    }
    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analyzeSingleFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 16); setBackgroundColor(0xFFF7F8FA.toInt()) }
        val title = TextView(this).apply { text = "CodexPro Analyzer"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF182230.toInt()) }
        val subtitle = TextView(this).apply { text = "Offline source-code and project inspection"; textSize = 14f; setTextColor(0xFF526071.toInt()); setPadding(0, 4, 0, 18) }
        root.addView(title); root.addView(subtitle)
        root.addView(actionButton("Analyze project folder") { openTree.launch(null) })
        root.addView(actionButton("Analyze one file") { openFile.launch(arrayOf("*/*")) })
        searchInput = EditText(this).apply { hint = "Search term or symbol"; singleLine = true }
        root.addView(searchInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(actionButton("Search selected project") {
            val uri = selectedTree
            if (uri == null) Toast.makeText(this, "Choose a project folder first", Toast.LENGTH_SHORT).show()
            else searchTree(uri, searchInput.text.toString().trim())
        })
        output = TextView(this).apply { text = "Choose a project folder or a source file to begin.\n\nWhat it checks:\n• File types and project manifests\n• Source file inventory\n• Keyword/symbol search\n• Basic hard-coded secret indicators\n\nAnalysis runs locally on this device."; textSize = 14f; setTextColor(0xFF253244.toInt()); setTextIsSelectable(true); setPadding(14, 14, 14, 14) }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }

    private fun analyzeSingleFile(uri: Uri) {
        try {
            val name = DocumentFile.fromSingleUri(this, uri)?.name ?: "selected-file"
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readTextLimited(1_500_000) } ?: ""
            output.text = "FILE REPORT\n==========\nName: $name\nBytes (text estimate): ${text.toByteArray().size}\nDetected type: ${kind(name)}\nLines: ${text.lineSequence().count()}\n\n${secretFindings(text)}\n\nPreview:\n${text.take(5000)}"
        } catch (e: Exception) { output.text = "Could not read file: ${e.message}" }
    }

    private fun analyzeTree(uri: Uri) {
        val root = DocumentFile.fromTreeUri(this, uri)
        if (root == null) { output.text = "Could not open selected folder."; return }
        val files = mutableListOf<DocumentFile>()
        collect(root, files, 0)
        val extCounts = files.groupingBy { it.name?.substringAfterLast('.', "[no extension]")?.lowercase(Locale.ROOT) ?: "[unknown]" }.eachCount().toList().sortedByDescending { it.second }
        val manifests = files.filter { (it.name ?: "") in setOf("package.json", "package-lock.json", "composer.json", "Cargo.toml", "pyproject.toml", "requirements.txt", "pom.xml", "build.gradle", "build.gradle.kts", "AndroidManifest.xml", "pubspec.yaml", "go.mod") }
        val source = files.filter { isTextCandidate(it.name ?: "") }
        val findings = mutableListOf<String>()
        var scanned = 0
        for (f in source.take(4000)) {
            val content = readText(f, 250_000) ?: continue
            scanned++
            val hit = secretFindings(content, f.name ?: "file")
            if (hit.contains("Possible hard-coded secret indicators")) findings.add(hit)
        }
        output.text = buildString {
            append("PROJECT REPORT\n=============\nFolder: ${root.name}\nFiles found: ${files.size}\nText/source candidates: ${source.size}\nFiles scanned for indicators: $scanned\n\nFILE TYPES\n----------\n")
            extCounts.take(25).forEach { append("${it.first}: ${it.second}\n") }
            append("\nPROJECT MANIFESTS\n-----------------\n")
            if (manifests.isEmpty()) append("No common dependency/build manifest found.\n") else manifests.take(100).forEach { append("• ${it.name}\n") }
            append("\nBASIC SECURITY CHECK\n--------------------\n")
            if (findings.isEmpty()) append("No common hard-coded secret patterns detected in the scanned text files. This is not a security guarantee.\n") else findings.take(50).forEach { append(it).append("\n") }
            append("\nLIMITS\n------\nThis is a local static scan, not decryption, execution, or a full security audit. Large projects are capped at 4,000 candidate files.")
        }
    }

    private fun searchTree(uri: Uri, query: String) {
        if (query.isBlank()) { Toast.makeText(this, "Enter a search term", Toast.LENGTH_SHORT).show(); return }
        val root = DocumentFile.fromTreeUri(this, uri) ?: return
        val files = mutableListOf<DocumentFile>(); collect(root, files, 0)
        val hits = mutableListOf<String>(); var scanned = 0
        for (f in files.filter { isTextCandidate(it.name ?: "") }.take(4000)) {
            val content = readText(f, 250_000) ?: continue; scanned++
            content.lineSequence().forEachIndexed { index, line -> if (line.contains(query, ignoreCase = true) && hits.size < 300) hits.add("${f.name}:${index + 1}: ${line.trim().take(240)}") }
            if (hits.size >= 300) break
        }
        output.text = "SEARCH REPORT\n=============\nQuery: $query\nFiles scanned: $scanned\nMatches: ${hits.size}\n\n" + (if (hits.isEmpty()) "No matches found in scanned files." else hits.joinToString("\n"))
    }

    private fun collect(dir: DocumentFile, out: MutableList<DocumentFile>, depth: Int) {
        if (depth > 20 || out.size >= 10000) return
        try { for (child in dir.listFiles()) { if (child.isDirectory) { if ((child.name ?: "") !in setOf(".git", "node_modules", "vendor", "build", ".gradle")) collect(child, out, depth + 1) } else if (child.isFile) out.add(child) } } catch (_: Exception) { }
    }

    private fun readText(file: DocumentFile, max: Int): String? = try { contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { it.readTextLimited(max) } } catch (_: Exception) { null }
    private fun java.io.Reader.readTextLimited(max: Int): String { val b = StringBuilder(); val buf = CharArray(8192); while (b.length < max) { val n = read(buf, 0, minOf(buf.size, max - b.length)); if (n < 0) break; b.append(buf, 0, n) }; return b.toString() }
    private fun kind(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) { "kt" -> "Kotlin"; "java" -> "Java"; "ts", "tsx" -> "TypeScript"; "js", "jsx", "mjs", "cjs" -> "JavaScript"; "py" -> "Python"; "php" -> "PHP"; "html", "htm" -> "HTML"; "css" -> "CSS"; "json" -> "JSON/config"; "xml" -> "XML"; "md" -> "Markdown"; "yml", "yaml" -> "YAML"; "sh" -> "Shell"; "sql" -> "SQL"; else -> "Unknown/text file" }
    private fun isTextCandidate(name: String): Boolean = name.substringAfterLast('.', "").lowercase(Locale.ROOT) in setOf("kt","java","ts","tsx","js","jsx","mjs","cjs","py","php","html","htm","css","json","xml","md","yml","yaml","sh","sql","go","rs","c","h","cpp","hpp","rb","swift","dart","toml","ini","env.example","txt","gradle","kts","properties") || name in setOf("Dockerfile", "Makefile", "Gemfile")
    private fun secretFindings(content: String, fileName: String = ""): String {
        val rules = listOf(
            """(?i)\b(api[_-]?key|secret|access[_-]?token|private[_-]?key)\b\s*[:=]\s*['"][^'"\s]{8,}""" to "credential-like assignment",
            """(?i)\bAKIA[0-9A-Z]{16}\b""" to "AWS access-key-like string",
            """-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----""" to "private-key marker"
        )
        val matches = rules.filter { Regex(it.first).containsMatchIn(content) }.map { it.second }
        return if (matches.isEmpty()) "No common hard-coded secret patterns detected." else "Possible hard-coded secret indicators in $fileName: ${matches.distinct().joinToString(", ")}. Review locally; false positives are possible."
    }
}
