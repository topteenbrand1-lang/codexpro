# Android + Web implementation plan

## Recommended staged architecture

### Stage 1 — Stabilize core (required)
- Restore dependencies from the committed lockfile using Node.js >=20.
- Pass TypeScript build, all smoke tests, stress tests, npm audit review, release packaging, and package-install smoke test.
- Preserve the existing MCP/HTTP protocol and avoid changing core security behavior while building the UI.

### Stage 2 — Web interface
- Keep the existing `src/http.ts` configuration UI as the first-party local control panel.
- If a richer dashboard is needed, build it as a separate browser client (for example Vite + TypeScript) and document its API contract.
- Add authenticated API endpoints only for specific, necessary actions. Use strict schema validation, same-origin/CSRF protections for cookie sessions if introduced, restrictive CORS, rate limits, safe error messages, and no secrets in browser storage/logs.
- Do not expose generic shell, arbitrary file paths, tokens, or handoff execution through a public browser UI.
- Default to loopback/local-only. Public access must remain opt-in and authenticated.

### Stage 3 — Android

Two distinct options must not be confused:

1. **Android companion client (simpler):** a WebView/PWA that connects to an already running CodexPro service. This is not a self-contained APK server and needs a clear connection/setup screen.
2. **Self-contained Android app (harder):** package/launch the Node runtime and CodexPro core, manage service lifecycle and local storage, restrict listening to loopback by default, and define how tunnels and background execution behave. This requires device-specific testing and may not be practical with a basic WebView wrapper.

Before releasing an APK, test fresh install, upgrade, offline start, server restart, Android process kill/restart, storage permissions, network loss, authentication, and token redaction. Sign release APKs securely and never ship personal tokens in the APK.

## Acceptance criteria
- Clean dependency installation from lockfile.
- Build and complete automated test suite pass.
- No unresolved high-severity dependency audit findings without documented disposition.
- Browser UI cannot reach unapproved filesystem/shell actions.
- Android build installs and launches on a real device and its behavior matches the declared architecture.
- Public tunnel use is opt-in and authenticated; secrets never appear in logs or screenshots.
- Build artifacts and test evidence are attached to the release.
