# CodexPro Android Analyzer — source bundle

এই bundle-এ আপনার দেওয়া CodexPro v0.30.2 source-এর সঙ্গে একটি আলাদা, native Android source-analysis app project যোগ করা হয়েছে।

## অ্যাপটি কী করে
- ফোন থেকে Android Storage Access Framework দিয়ে একটি project folder বা একক file বেছে নেয়
- file type এবং সাধারণ dependency/build manifest শনাক্ত করে
- source/text file-এ keyword বা symbol খোঁজে
- কিছু সাধারণ hard-coded secret pattern-এর সম্ভাব্য উপস্থিতি দেখায়
- বিশ্লেষণ ডিভাইসেই চালায়; কোনো server-এ file upload করে না

## গুরুত্বপূর্ণ সীমা
- এটি মূল CodexPro Node.js MCP server-কে Android-এ port করে না এবং MCP client নয়। এটি companion static analyzer app।
- কোনো নাম লিখে proprietary software-এর source code, password বা encryption key জাদুর মতো উদ্ধার করতে পারে না। Encrypted/protected software decrypt করার দাবি করে না।
- secret scan heuristic; false positive/negative হতে পারে।
- এই ZIP-এ তৈরি করা APK নেই। বর্তমান build environment-এ Android SDK/Gradle নেই, তাই এখানে APK build ও test করা সম্ভব হয়নি।

## APK build
GitHub Actions workflow `.github/workflows/build-android-apk.yml` যোগ করা হয়েছে। এই bundle-টি GitHub repository-তে push করার পর Actions থেকে **Build CodexPro Analyzer APK** workflow চালালে `CodexPro-Analyzer-debug-apk` নামে artifact তৈরি হওয়ার কথা। Build সফল হয়েছে—এমন দাবি করা হচ্ছে না যতক্ষণ না workflow বাস্তবে run হয়।

## Project layout
- `android-app/` — Android Studio/Gradle source project
- `src/`, `dist/`, `scripts/` — আপনার দেওয়া CodexPro source
- `.github/workflows/build-android-apk.yml` — cloud APK build workflow
