# CodexPro Analyzer Android prototype

This is an Android companion prototype added beside the existing CodexPro Node.js MCP server. It is **not** a bundled Android port of the MCP server.

## What it does
- Opens a user-selected APK or ZIP using Android's system file picker.
- Locally lists archive entries and summarizes DEX files, native libraries and resources.
- Searches the generated inventory/report by a name or module keyword.
- Does not upload selected files.

## Limits
This first version performs archive inventory only. It does not decompile DEX bytecode into Java/Kotlin, bypass DRM, decrypt protected code, or guarantee that any software can be decoded from its name alone. Full server functionality is not bundled; CodexPro itself is a Node.js MCP server and needs a separate Android runtime/integration effort.

## Build
From this directory with JDK 17, Gradle 8.9 and Android SDK platform/build-tools 35 installed:

```sh
gradle assembleDebug
```

The GitHub Actions workflow at `.github/workflows/android-apk.yml` builds a debug APK and uploads it as an artifact when run manually or when Android files change.
