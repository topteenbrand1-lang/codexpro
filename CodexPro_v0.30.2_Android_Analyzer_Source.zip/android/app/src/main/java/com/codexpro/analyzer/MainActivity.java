package com.codexpro.analyzer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.Color;
import android.util.TypedValue;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.Enumeration;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 41;
    private TextView output;
    private EditText search;
    private File selectedCopy;
    private String report = "Select an APK or ZIP file to inspect its archive structure.";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(18)); root.setBackgroundColor(Color.rgb(247,248,250));
        TextView title = new TextView(this); title.setText("CodexPro Analyzer"); title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25); title.setTypeface(null, Typeface.BOLD); title.setTextColor(Color.rgb(24,35,55));
        TextView intro = new TextView(this); intro.setText("Local software inspection · APK / ZIP archive inventory"); intro.setTextSize(14); intro.setPadding(0, dp(5), 0, dp(14));
        Button pick = new Button(this); pick.setText("Choose APK or ZIP"); pick.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_FILE); });
        search = new EditText(this); search.setSingleLine(true); search.setHint("Search file names / modules");
        Button find = new Button(this); find.setText("Search report"); find.setOnClickListener(v -> showSearch());
        output = new TextView(this); output.setTextSize(13); output.setTextColor(Color.rgb(32,42,58)); output.setTextIsSelectable(true); output.setPadding(dp(12),dp(12),dp(12),dp(12)); output.setText(report);
        ScrollView scroll = new ScrollView(this); scroll.addView(output);
        root.addView(title); root.addView(intro); root.addView(pick); root.addView(search); root.addView(find);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1)); setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            selectedCopy = new File(getCacheDir(), "selected-archive.bin");
            try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(selectedCopy)) {
                if (in == null) throw new Exception("Could not open selected file.");
                byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            }
            report = inspect(selectedCopy, uri.getLastPathSegment()); output.setText(report);
        } catch (Exception e) { report = "Inspection failed: " + e.getMessage(); output.setText(report); }
    }

    private String inspect(File file, String name) throws Exception {
        StringBuilder b = new StringBuilder(); int count = 0, dex = 0, nativeLibs = 0, resources = 0;
        b.append("FILE: ").append(name).append("\nSIZE: ").append(file.length()).append(" bytes\n\nARCHIVE INVENTORY\n");
        try (ZipFile zip = new ZipFile(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement(); if (e.isDirectory()) continue; count++;
                String path = e.getName(); String lower = path.toLowerCase(Locale.ROOT);
                if (lower.matches("(^|.*/)classes([0-9]*)\\.dex$")) dex++;
                if (lower.startsWith("lib/") && lower.endsWith(".so")) nativeLibs++;
                if (lower.startsWith("res/") || lower.startsWith("resources/")) resources++;
                if (count <= 700) b.append(String.format(Locale.ROOT, "%4d  %s%s\n", count, path, e.getSize() >= 0 ? " (" + e.getSize() + " B)" : ""));
            }
        }
        b.append("\nSUMMARY\nFiles: ").append(count).append("\nDEX bytecode files: ").append(dex).append("\nNative libraries (.so): ").append(nativeLibs).append("\nResource entries: ").append(resources).append("\n");
        if (count > 700) b.append("\nShowing first 700 entries only.\n");
        b.append("\nLIMITATION\nThis is static archive inspection, not full decompilation. Encrypted, obfuscated, or protected code may not be readable. No files are uploaded; inspection runs on this device.");
        return b.toString();
    }

    private void showSearch() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) { output.setText(report); return; }
        StringBuilder b = new StringBuilder("SEARCH RESULTS: ").append(q).append("\n\n"); int hits = 0;
        for (String line : report.split("\\n")) if (line.toLowerCase(Locale.ROOT).contains(q)) { b.append(line).append('\n'); hits++; }
        if (hits == 0) b.append("No matching text in the current report. Select a file first or try another term.");
        output.setText(b.toString());
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
