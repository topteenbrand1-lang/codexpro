# আগে এটি পড়ুন

এটি CodexPro-এর আপডেট করা সোর্স কোডের backup, যার সঙ্গে একটি Android Analyzer companion app-এর source project যুক্ত হয়েছে। এটি এখনো ইনস্টলযোগ্য APK নয়। APK বানাতে GitHub Actions/Android SDK দিয়ে build করতে হবে। ZIP খুললেই Android-এ install করা যাবে না।
